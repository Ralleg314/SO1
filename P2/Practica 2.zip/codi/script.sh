#!/bin/bash     

rm myprog

clear

echo "Compiling files.."
#gcc ...
echo "Linking files.."
#gcc ...
echo "Cleaning files"
rm -f *.o *~
echo "Executing myprog.."
#./myprog
echo "Done!"