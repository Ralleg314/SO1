void write_pid(int,int);
int read_pid(int);
